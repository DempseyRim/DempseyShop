<?php 

$conexion=mysqli_connect("localhost","id17036517_root","qriF8|KwHJWC99q","id17036517_box");
/* host de la bd("localhost"), usuario de la bd("root") ,contrasenia (""), nombre de la bd ("box")*/
//$conexion=mysqli_connect("localhost","root","","box");
?>