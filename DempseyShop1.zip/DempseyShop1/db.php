<?php 

$conexion=mysqli_connect("localhost","root","","box");
/* host de la bd("localhost"), usuario de la bd("root") ,contrasenia (""), nombre de la bd ("box")*/
//$conexion=mysqli_connect("localhost","root","","box");
?>